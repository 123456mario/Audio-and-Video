class MixerError(Exception):
    """Base error class for Mixer ."""

    pass
